
n: int = int(input("inserisci il numero: "))
if n % 2 == 0:
    print("il numero inserito è pari")    
else:
        print("il numero inserito è dispari")
    