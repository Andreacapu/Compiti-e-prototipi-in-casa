

i = 0
somma = 0
n: int = int(input("Inserisci numero: "))
while i < n:
    somma = somma + i
    i += 1
    
    
    print (i)